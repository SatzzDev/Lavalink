# ⚡ QUICK START GUIDE

## 1. Install Dependencies
```bash
npm install
```

## 2. Update Admin Number
Edit `index.ts` line ~33:
```typescript
const ADMIN = 'YOUR_NUMBER@s.whatsapp.net';
```

Example:
```typescript
const ADMIN = '6282170988479@s.whatsapp.net';
```

## 3. Start Bot
```bash
npm start
```

Scan QR code dengan WhatsApp ketika muncul.

## 4. Test Commands

### Add User
```
.adduser 6285210524612@s.whatsapp.net john_doe pass123
```

### List Users
```
.listuser
```

### Upload Video to Status

1. Send video file
2. Reply with:
```
.upsw "Your caption" "#000000" 0
```

## API Endpoints

```
POST   http://localhost:3000/api/upload-status
GET    http://localhost:3000/api/uploads
DELETE http://localhost:3000/api/uploads/{filename}
```

## Upload via Command Line

**Node.js:**
```bash
node upload-client.js video.mp4 "Caption" "#FF5733" 2
```

**Python:**
```bash
python upload-client.py video.mp4 "Caption" "#FF5733" 2
```

## Troubleshooting

### Port Already in Use
Edit `server.ts` change `PORT = 3001`

### Module Not Found
```bash
npm install express multer form-data axios
```

### Video Not Sending
- Check if bot is logged in (QR code scanned)
- Check Express server is running
- Check users in database

## Files Reference

| File | Purpose |
|------|---------|
| `index.ts` | Main bot |
| `server.ts` | API server |
| `db.json` | User database |
| `README.md` | Full documentation |
| `API_DOCUMENTATION.md` | API reference |
| `SETUP_GUIDE.md` | Detailed setup |

---

**More help:** See `README.md` or `SETUP_GUIDE.md`
