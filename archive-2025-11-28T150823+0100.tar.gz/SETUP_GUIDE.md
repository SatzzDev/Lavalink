# SETUP GUIDE - WhatsApp Bot dengan Status Upload

## ✅ Perubahan yang Telah Dilakukan

### 1. **Removed Store/Payment Features**
   - ❌ Dihapus command: `.order`, `.payment`, `.bukti`, `.admin approve/reject`, `.status`
   - ❌ Dihapus database schema untuk payments
   - ✅ Updated db.json dengan struktur user baru

### 2. **Added User Management System**
   - ✅ `.adduser <JID> <username> <password>` - Tambah user
   - ✅ `.listuser` - Lihat daftar user
   - ✅ `.deluser <JID>` - Hapus user

### 3. **Added Express.js Server**
   - ✅ Created `server.ts` - Express API server
   - ✅ Upload endpoint: `POST /api/upload-status`
   - ✅ List endpoint: `GET /api/uploads`
   - ✅ Delete endpoint: `DELETE /api/uploads/:filename`

### 4. **Added Status Broadcast Feature**
   - ✅ `.upsw [caption] [bgColor] [font]` - Upload video ke status
   - ✅ Auto-broadcast ke semua user di database
   - ✅ Auto-cleanup file setelah dikirim

### 5. **Updated Dependencies**
   - ✅ Added: `express`, `multer`, `form-data`, `axios`
   - ✅ Added DevDep: `@types/express`, `@types/multer`

### 6. **Fixed TypeScript Config**
   - ✅ Updated tsconfig.json untuk support DOM APIs
   - ✅ Disabled strict mode untuk kompatibilitas

## 📋 File yang Dibuat/Dimodifikasi

### Created Files:
```
✅ server.ts                 - Express server untuk upload
✅ upload-client.js          - Client untuk upload via Node.js
✅ upload-client.py          - Client untuk upload via Python
✅ API_DOCUMENTATION.md      - Dokumentasi API lengkap
✅ README.md                 - Dokumentasi lengkap
✅ public/uploads/           - Directory untuk temporary files
✅ SETUP_GUIDE.md            - File ini
```

### Modified Files:
```
✅ index.ts                  - Update commands & integrasi server
✅ db.json                   - Update database schema
✅ package.json              - Add dependencies
✅ tsconfig.json             - Fix TypeScript config
```

## 🚀 Langkah-Langkah Setup

### Step 1: Install Dependencies
```bash
cd c:\Users\ASUS\Documents\SELFBOT
npm install
```

Jika ada error, install manual:
```bash
npm install express multer form-data axios
npm install --save-dev @types/express @types/multer
```

### Step 2: Konfigurasi Admin JID
Edit `index.ts` line ~33:
```typescript
const ADMIN = '6282170988479@s.whatsapp.net';
```

Ganti dengan nomor WhatsApp admin Anda.

### Step 3: Start Bot
```bash
npm start
```

Atau untuk development dengan auto-reload:
```bash
npm run dev
```

Bot akan mengeluarkan QR code di terminal. Scan dengan WhatsApp.

## 📱 Cara Menggunakan

### A. User Management (Admin Only)

**1. Tambah User:**
```
.adduser 6282170988479@s.whatsapp.net john_doe password123
```

**2. Lihat Semua User:**
```
.listuser
```

**3. Hapus User:**
```
.deluser 6282170988479@s.whatsapp.net
```

### B. Upload Video ke Status

**Metode 1: Langsung dari WhatsApp**

1. Kirim video file ke admin
2. Reply video dengan:
```
.upsw "Caption text" "#FF5733" 2
```

Parameter:
- Caption: Text yang tampil (opsional)
- Background Color: Hex color (optional, default #000000)
- Font: 0-5 (optional, default 0)

**Metode 2: Via HTTP API (Node.js)**
```bash
node upload-client.js video.mp4 "Hello World" "#FF5733" 2
```

**Metode 3: Via HTTP API (Python)**
```bash
python upload-client.py video.mp4 "Hello World" "#FF5733" 2
```

**Metode 4: Via cURL**
```bash
curl -X POST http://localhost:3000/api/upload-status \
  -F "video=@video.mp4" \
  -F "caption=Hello World" \
  -F "backgroundColor=#FF5733" \
  -F "font=2"
```

## 📊 Database Structure

### db.json
```json
{
  "users": {
    "6282170988479@s.whatsapp.net": {
      "username": "john_doe",
      "password": "pass123",
      "createdAt": "2025-11-28T12:00:00.000Z"
    }
  }
}
```

## 🔌 API Endpoints

**Base URL:** `http://localhost:3000`

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| POST | `/api/upload-status` | Upload video untuk status |
| GET | `/api/uploads` | List semua video |
| DELETE | `/api/uploads/:filename` | Hapus video |
| POST | `/api/cleanup/:filename` | Cleanup file |

## 📋 Command Reference

```
👥 User Management:
  .adduser <JID> <username> <password> - Tambah user
  .listuser                              - Lihat daftar user
  .deluser <JID>                         - Hapus user

📤 Status Upload:
  .upsw [caption] [bgColor] [font]      - Upload video ke status

ℹ️ Other:
  .help / .menu                          - Tampilkan menu
```

## ⚠️ Important Notes

1. **Admin Only**: User management & upload hanya bisa dilakukan admin
2. **Default Admin**: Ganti `ADMIN` di `index.ts` dengan nomor Anda
3. **Max File Size**: 100MB per video
4. **Supported Format**: mp4, mov, avi, mkv
5. **Port**: Express server berjalan di port 3000
6. **Auto Cleanup**: Video dihapus 5 detik setelah dikirim

## 🐛 Troubleshooting

### Error: Cannot find module 'express'
```bash
npm install express multer form-data axios
```

### Port 3000 already in use
Edit `server.ts` ganti port:
```typescript
const PORT = 3001; // Atau nomor lain
```

### Video tidak terkirim ke status
- Pastikan bot sudah login (QR code sudah di-scan)
- Pastikan Express server berjalan (check console)
- Pastikan ada user di database
- Check console untuk error messages

### Upload via API gagal
- Pastikan Express server berjalan: `http://localhost:3000`
- Cek format video
- Cek ukuran file (max 100MB)
- Check CORS jika request dari browser

## 📁 Project Structure

```
SELFBOT/
├── index.ts                      # Main WhatsApp bot
├── server.ts                     # Express.js server
├── db.json                       # User database
├── package.json                  # Dependencies
├── tsconfig.json                 # TypeScript config
├── upload-client.js              # Upload client (Node.js)
├── upload-client.py              # Upload client (Python)
├── README.md                     # Documentation
├── API_DOCUMENTATION.md          # API docs
├── SETUP_GUIDE.md               # Guide ini
├── public/
│   └── uploads/                 # Video storage (temporary)
├── session/                     # WhatsApp session
└── dist/                        # Compiled output (jika di-build)
```

## 🔄 Flow Diagram

```
User WhatsApp (Admin)
        ↓
    .upsw command + video
        ↓
Bot menerima & download video
        ↓
Bot upload ke Express API
        ↓
Express simpan di /public/uploads
        ↓
Express emit 'video-uploaded' event
        ↓
Bot listen & dapat notifikasi
        ↓
Bot kirim ke 'status@broadcast'
(mencakup semua user dari db.json)
        ↓
✅ Video ada di status semua user
        ↓
Auto cleanup file (5 detik)
```

## 📞 Support

Jika ada masalah:

1. Check console untuk error messages
2. Pastikan semua dependencies terinstall: `npm list`
3. Pastikan tsconfig.json benar
4. Cek network connection & firewall
5. Cek WhatsApp session (scan QR code lagi jika perlu)

## ✨ Next Steps

- [x] User management system ready
- [x] Express API server ready
- [x] Status upload feature ready
- [ ] Add password hashing (untuk security)
- [ ] Add group broadcast support
- [ ] Add scheduled uploads
- [ ] Add upload history tracking

---

**Setup selesai! Bot siap digunakan.** 🎉

Run command: `npm start` atau `npm run dev`
