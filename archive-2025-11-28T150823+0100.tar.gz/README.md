# WhatsApp Bot - User Management & Status Upload

Bot WhatsApp yang dilengkapi dengan fitur manajemen database user dan upload video ke status.

## Fitur

✅ **User Management**
- `.adduser <JID> <username> <password>` - Tambah user baru
- `.listuser` - Lihat daftar semua user
- `.deluser <JID>` - Hapus user

📤 **Status Upload**
- `.upsw [caption] [bgColor] [font]` - Upload video ke status broadcast semua user

## Instalasi

### 1. Clone/Setup Project
```bash
cd c:\Users\ASUS\Documents\SELFBOT
npm install
```

### 2. Install Dependencies Baru
```bash
npm install express multer form-data axios
npm install --save-dev @types/express @types/multer
```

### 3. Configure tsconfig.json
File sudah dikonfigurasi, tapi pastikan setting berikut:
```json
{
  "compilerOptions": {
    "lib": ["ES2020", "DOM"],
    "strict": false
  }
}
```

### 4. Jalankan Bot
```bash
npm start
```

Atau untuk development:
```bash
npm run dev
```

## Struktur Project

```
SELFBOT/
├── index.ts                    # Main bot file
├── server.ts                   # Express server (upload handler)
├── db.json                     # Database user
├── package.json                # Dependencies
├── tsconfig.json               # TypeScript config
├── API_DOCUMENTATION.md        # API docs
├── public/
│   └── uploads/                # Temporary video storage
└── session/                    # WhatsApp session files
```

## Konfigurasi

### Admin JID
Edit `index.ts` line ~33:
```typescript
const ADMIN = '6282170988479@s.whatsapp.net';
```

Ganti dengan nomor WhatsApp admin Anda (format: <nomor>@s.whatsapp.net)

### Port Express
Edit `server.ts` line ~8:
```typescript
const PORT = 3000;
```

## Database Schema

### db.json
```json
{
  "users": {
    "6282170988479@s.whatsapp.net": {
      "username": "john_doe",
      "password": "pass123",
      "createdAt": "2025-11-28T12:00:00.000Z"
    }
  }
}
```

## Cara Penggunaan

### 1. Tambah User (Admin Only)
```
.adduser 6282170988479@s.whatsapp.net john_doe password123
```

Response:
```
✅ User berhasil ditambahkan!

👤 JID: 6282170988479@s.whatsapp.net
📝 Username: john_doe
🔑 Password: password123
```

### 2. Lihat Daftar User (Admin Only)
```
.listuser
```

Response:
```
╭─❑ DAFTAR USER ❑─
│
│ 1. john_doe
│    JID: 6282170988479@s.whatsapp.net
│    Pass: password123
│    Created: 28/11/2025, 12:00:00
│
╰────────────────

Total: 1 user
```

### 3. Hapus User (Admin Only)
```
.deluser 6282170988479@s.whatsapp.net
```

Response:
```
✅ User john_doe (6282170988479@s.whatsapp.net) berhasil dihapus!
```

### 4. Upload Video ke Status

**Langkah 1:** Kirim video file

**Langkah 2:** Reply video dengan command:
```
.upsw "Caption text" "#FF5733" 2
```

Parameters:
- Caption: Teks yang ditampilkan di status (opsional)
- Background Color: Hex color code (default: #000000)
- Font: 0-5 (default: 0)

Response:
```
✅ Video berhasil diupload!

📤 URL: http://localhost:3000/uploads/video-xxx.mp4
📝 Caption: Caption text
🎨 Background: #FF5733
🔤 Font: 2

⏳ Video akan dikirim ke semua user...
```

## API Endpoints

### Upload Video
**POST** `http://localhost:3000/api/upload-status`

```bash
curl -X POST http://localhost:3000/api/upload-status \
  -F "video=@video.mp4" \
  -F "caption=Hello" \
  -F "backgroundColor=#FF5733" \
  -F "font=2"
```

### List Uploads
**GET** `http://localhost:3000/api/uploads`

```bash
curl http://localhost:3000/api/uploads
```

### Delete File
**DELETE** `http://localhost:3000/api/uploads/{filename}`

```bash
curl -X DELETE http://localhost:3000/api/uploads/video-xxx.mp4
```

Lihat `API_DOCUMENTATION.md` untuk dokumentasi lengkap.

## Flow Diagram

```
WhatsApp User (Admin)
        ↓
     .upsw command + video file
        ↓
    Bot menerima pesan
        ↓
   Bot download video
        ↓
 Bot upload ke Express API
        ↓
 Express simpan di /public/uploads
        ↓
 Express emit event 'video-uploaded'
        ↓
  Bot listen ke event
        ↓
Bot kirim ke status@broadcast
  (ke semua user di db.json)
        ↓
✅ Video ada di status semua user
        ↓
Auto cleanup file (5 detik kemudian)
```

## Troubleshooting

### Error: Cannot find module 'express'
```bash
npm install express multer form-data axios
```

### Error: Port 3000 already in use
Ganti port di `server.ts`:
```typescript
const PORT = 3001; // atau nomor port lain
```

### Video tidak terkirim ke status
- Pastikan semua user terdaftar di `db.json`
- Check console untuk error messages
- Pastikan bot sudah login (QR code sudah di-scan)
- Cek connection ke Express server (port 3000)

### Upload gagal
- Cek ukuran file (max 100MB)
- Format video harus mp4, mov, avi, atau mkv
- Pastikan Express server berjalan

## File Auto-Cleanup

Video yang sudah dikirim ke status akan otomatis dihapus dari `/public/uploads` setelah 5 detik.

## Keamanan

⚠️ **NOTES:**
- Ganti `ADMIN` JID dengan nomor Anda sendiri
- Password user disimpan dalam plain text (bisa di-hash untuk production)
- Express server hanya accessible di `http://localhost:3000`
- Upload limit: 100MB per file

## Developer

Bot ini menggunakan:
- **Baileys** - WhatsApp Web API
- **Express.js** - Web server
- **Multer** - File upload handling
- **TypeScript** - Type-safe JavaScript

## License

MIT License

---

**Created with ❤️ using Baileys & Express.js**
