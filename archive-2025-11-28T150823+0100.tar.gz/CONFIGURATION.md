# Configuration Template

Gunakan file ini untuk reference konfigurasi.

## Admin Configuration

Edit di `index.ts` line ~33:

```typescript
// ============ CONFIG ============
const ADMIN = '6282170988479@s.whatsapp.net';
```

### Format JID (Jabber ID):
- WhatsApp Personal: `628XXXXXXXXXX@s.whatsapp.net`
- WhatsApp Business: `628XXXXXXXXXX@s.whatsapp.net`
- Contoh: `6282170988479@s.whatsapp.net` (Indonesia +62)

## Express Server Configuration

Edit di `server.ts` line ~8:

```typescript
const PORT = 3000;
```

### Konfigurasi Lain di server.ts:

```typescript
// Max file size
limits: {
    fileSize: 100 * 1024 * 1024 // 100MB
}

// Supported video types
const allowedMimes = [
    'video/mp4',
    'video/quicktime',    // .mov
    'video/x-msvideo',    // .avi
    'video/x-matroska'    // .mkv
];

// Upload directory
uploadDir = path.join(__dirname, 'public', 'uploads');

// File cleanup timeout
setTimeout(() => { /* cleanup */ }, 5000); // 5 detik
```

## Database Configuration

File: `db.json`

### Schema User:
```json
{
  "username": "john_doe",
  "password": "pass123",
  "createdAt": "2025-11-28T12:00:00.000Z"
}
```

## TypeScript Configuration

File: `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM"],
    "strict": false,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "allowJs": true
  }
}
```

## Status Upload Parameters

Gunakan dalam command `.upsw`:

```
.upsw [caption] [backgroundColor] [font]
```

### backgroundColor (Hex Color):
- `#000000` - Hitam (default)
- `#FF5733` - Merah
- `#3399FF` - Biru
- `#00CC00` - Hijau
- `#FFFF00` - Kuning

### font (0-5):
- `0` - Default (default)
- `1` - Bold
- `2` - Italic
- `3` - Bold Italic
- `4` - Monospace
- `5` - Serif

## Environment Variables (Optional)

Jika ingin menggunakan .env file:

```bash
# .env
ADMIN_JID=6282170988479@s.whatsapp.net
EXPRESS_PORT=3000
MAX_FILE_SIZE=104857600
VIDEO_CLEANUP_DELAY=5000
```

Kemudian di `index.ts`:
```typescript
import dotenv from 'dotenv';
dotenv.config();

const ADMIN = process.env.ADMIN_JID || '6282170988479@s.whatsapp.net';
```

## Baileys Configuration

Di `index.ts` function `startBot()`:

```typescript
const sock = makeWASocket({
    version,
    logger,
    auth: state,
    printQRInTerminal: true,
    // Optional config:
    // generateHighQualityLinkPreview: true,
    // browser: ['Ubuntu', 'Chrome', '20.0.04'],
    // connectTimeoutMs: 60000,
    // defaultQueryTimeoutMs: 0,
    // disableSharing: false,
    // markOnlineAfterClosing: true,
    // syncFullHistory: false
}) as ExtendedWASocket;
```

## API Response Format

### Success Response:
```json
{
  "success": true,
  "message": "Video berhasil diupload dan akan dikirim ke status",
  "url": "http://localhost:3000/uploads/video-1234567890.mp4",
  "filename": "video-1234567890.mp4"
}
```

### Error Response:
```json
{
  "error": "Error message here"
}
```

## Logging Configuration

Di `index.ts`:

```typescript
const logger = P({ 
    level: 'silent'  // 'silent', 'error', 'warn', 'info', 'debug'
});
```

## File Storage Path

```
project-root/
├── public/
│   └── uploads/              ← Video disimpan di sini
│       ├── video-123456.mp4
│       ├── video-234567.mp4
│       └── video-345678.mp4
```

## Port Configuration Reference

| Service | Port | Config Location |
|---------|------|-----------------|
| Express Server | 3000 | `server.ts` line 8 |
| WhatsApp (local) | - | (Baileys manages) |

## User Group Limits

Broadcast akan dikirim ke semua user dalam database:

```typescript
const userJids = Object.keys(db.users);
// Send to all user JIDs
```

Maximum recommended: 1000+ users (tested & stable)

## Security Notes

⚠️ **Production Setup:**
1. **Hash Passwords:**
   ```typescript
   import bcrypt from 'bcrypt';
   const hashedPass = await bcrypt.hash(password, 10);
   ```

2. **Use Environment Variables:**
   ```bash
   npm install dotenv
   ```

3. **Add API Authentication:**
   ```typescript
   app.use((req, res, next) => {
     const token = req.headers.authorization;
     if (token !== 'Bearer YOUR_SECRET_TOKEN') {
       return res.status(401).json({ error: 'Unauthorized' });
     }
     next();
   });
   ```

4. **Enable HTTPS:**
   ```typescript
   const https = require('https');
   https.createServer(sslOptions, app).listen(PORT);
   ```

## Performance Tuning

### Database Auto-Save
Edit `index.ts` line ~34:
```typescript
setInterval(() => saveDB(db), 30000); // 30 detik (default)
```

### File Cleanup Timeout
Edit `server.ts` line ~124:
```typescript
setTimeout(() => {
    // cleanup file
}, 5000); // 5 detik (default)
```

### Typing Delay
Edit `index.ts` dalam `reply` function:
```typescript
await delay(1500); // Delay untuk typing indicator (ms)
```

## Monitoring & Debugging

### Enable Debug Logging
```typescript
const logger = P({ level: 'debug' });

// Semua events akan di-log
sock.ev.on('messages.upsert', ({ messages }) => {
    console.log('Message received:', messages[0]);
});
```

### Monitor Upload Events
```typescript
uploadEvents.on('video-uploaded', (data) => {
    console.log('Upload event:', data);
});
```

---

**Need more customization? Check README.md or SETUP_GUIDE.md**
