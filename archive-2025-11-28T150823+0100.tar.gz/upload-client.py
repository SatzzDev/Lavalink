#!/usr/bin/env python3

"""
Upload Video Status via HTTP API
Script Python untuk upload video ke status

Usage:
    python upload-client.py <video_file> [caption] [bgColor] [font]

Example:
    python upload-client.py video.mp4 "Hello World" "#FF5733" 2
"""

import requests
import sys
import os
from pathlib import Path

def main():
    if len(sys.argv) < 2:
        print("""
╭─❑ VIDEO STATUS UPLOAD CLIENT ❑─
│
│ Usage: python upload-client.py <video_file> [caption] [bgColor] [font]
│
│ Parameters:
│ • video_file: Path ke file video (required)
│ • caption: Caption di status (optional, default: "Status dari Bot")
│ • bgColor: Warna background hex (optional, default: "#000000")
│ • font: Font style 0-5 (optional, default: "0")
│
│ Examples:
│ • python upload-client.py video.mp4
│ • python upload-client.py video.mp4 "Hello World"
│ • python upload-client.py video.mp4 "Hello World" "#FF5733" 2
│
╰────────────────
        """)
        sys.exit(0)

    video_file = sys.argv[1]
    caption = sys.argv[2] if len(sys.argv) > 2 else "Status dari Bot"
    bg_color = sys.argv[3] if len(sys.argv) > 3 else "#000000"
    font = sys.argv[4] if len(sys.argv) > 4 else "0"

    # Validasi file exists
    if not os.path.exists(video_file):
        print(f"❌ File tidak ditemukan: {video_file}")
        sys.exit(1)

    # Validasi file size
    file_size_mb = os.path.getsize(video_file) / (1024 * 1024)

    if file_size_mb > 100:
        print(f"❌ File terlalu besar: {file_size_mb:.2f}MB (max: 100MB)")
        sys.exit(1)

    print(f"""
╭─❑ UPLOADING... ❑─
│
│ 📁 File: {video_file}
│ 💾 Size: {file_size_mb:.2f}MB
│ 📝 Caption: {caption}
│ 🎨 BG Color: {bg_color}
│ 🔤 Font: {font}
│
╰────────────────
    """)

    try:
        # Prepare request
        files = {
            'video': open(video_file, 'rb'),
            'caption': (None, caption),
            'backgroundColor': (None, bg_color),
            'font': (None, font)
        }

        # Upload
        response = requests.post(
            'http://localhost:3000/api/upload-status',
            files=files,
            timeout=300  # 5 minutes timeout
        )

        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                print(f"""
✅ UPLOAD BERHASIL!

│ 📤 URL: {data['url']}
│ 📦 Filename: {data['filename']}
│ 📝 Caption: {caption}
│ 🎨 Background: {bg_color}
│ 🔤 Font: {font}
│
│ ℹ️ Video akan dikirim ke semua user
│    dalam status broadcast.
│
                """)
            else:
                print(f"❌ Upload Failed: {data.get('message', 'Unknown error')}")
        else:
            print(f"❌ Server Error: {response.status_code}")
            print(f"   Response: {response.text}")

    except requests.exceptions.ConnectionError:
        print("❌ Connection Error")
        print("   Make sure Express server is running on http://localhost:3000")
        sys.exit(1)
    except requests.exceptions.Timeout:
        print("❌ Request Timeout (File too large or slow connection)")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)

if __name__ == '__main__':
    main()
