import express, { Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { EventEmitter } from 'events';

// Create events emitter untuk komunikasi dengan bot
export const uploadEvents = new EventEmitter();

const app = express();
const PORT = process.env.SERVER_PORT || 3000;

// Setup storage untuk multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'public', 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const timestamp = Date.now();
        const originalName = path.parse(file.originalname).name;
        cb(null, `${originalName}-${timestamp}${path.extname(file.originalname)}`);
    }
});

const upload = multer({
    storage,
    fileFilter: (req, file, cb) => {
        // Hanya accept video files
        const allowedMimes = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/x-matroska'];
        if (allowedMimes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Hanya file video yang diperbolehkan'));
        }
    },
    limits: {
        fileSize: 100 * 1024 * 1024 // 100MB limit
    }
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Upload endpoint
app.post('/api/upload-status', upload.single('video'), (req: Request, res: Response) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'Tidak ada file yang diupload' });
        }

        const { caption = '', backgroundColor = '#000000', font = 0 } = req.body;

        const videoUrl = `http://de-05.orihost.com:${PORT}/uploads/${req.file.filename}`;

        // Emit event ke bot
        uploadEvents.emit('video-uploaded', {
            videoUrl,
            caption,
            backgroundColor,
            font,
            filename: req.file.filename,
            filePath: req.file.path
        });

        res.json({
            success: true,
            message: 'Video berhasil diupload dan akan dikirim ke status',
            url: videoUrl,
            filename: req.file.filename
        });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// List uploaded videos
app.get('/api/uploads', (req: Request, res: Response) => {
    const uploadDir = path.join(__dirname, 'public', 'uploads');
    try {
        if (!fs.existsSync(uploadDir)) {
            return res.json({ files: [] });
        }
        const files = fs.readdirSync(uploadDir);
        const fileDetails = files.map(file => ({
            filename: file,
            url: `http://de-05.orihost.com:${PORT}/uploads/${file}`,
            uploaded: fs.statSync(path.join(uploadDir, file)).birthtime
        }));
        res.json({ files: fileDetails });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Delete uploaded video
app.delete('/api/uploads/:filename', (req: Request, res: Response) => {
    const { filename } = req.params;
    const filePath = path.join(__dirname, 'public', 'uploads', filename);

    try {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.json({ success: true, message: 'File berhasil dihapus' });
        } else {
            res.status(404).json({ error: 'File tidak ditemukan' });
        }
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Cleanup endpoint - hapus file yang sudah dikirim
app.post('/api/cleanup/:filename', (req: Request, res: Response) => {
    const { filename } = req.params;
    const filePath = path.join(__dirname, 'public', 'uploads', filename);

    try {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.json({ success: true, message: 'File temporary berhasil dihapus' });
        } else {
            res.json({ success: true, message: 'File sudah tidak ada' });
        }
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

export const startServer = () => {
    app.listen(PORT, () => {
        console.log(`✅ Express server berjalan di http:/de-05.orihost.com:${PORT}`);
        console.log(`📁 Upload endpoint: POST http://de-05.orihost.com:${PORT}/api/upload-status`);
    });
};
