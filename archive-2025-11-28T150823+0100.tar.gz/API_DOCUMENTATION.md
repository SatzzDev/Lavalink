# API Documentation - Status Upload Server

## Endpoints

### 1. Upload Video to Status
**POST** `/api/upload-status`

Upload video yang akan dikirim ke status broadcast ke semua user.

**Request:**
- Method: `POST`
- Content-Type: `multipart/form-data`
- Parameters:
  - `video` (file, required): Video file (max 100MB)
  - `caption` (string, optional): Text caption untuk status (default: '')
  - `backgroundColor` (string, optional): Hex color code (default: '#000000')
  - `font` (number, optional): Font style 0-5 (default: 0)

**Example using cURL:**
```bash
curl -X POST http://localhost:3000/api/upload-status \
  -F "video=@video.mp4" \
  -F "caption=Hello World" \
  -F "backgroundColor=#FF5733" \
  -F "font=2"
```

**Example using JavaScript/Fetch:**
```javascript
const formData = new FormData();
formData.append('video', videoFile);
formData.append('caption', 'Hello from Bot');
formData.append('backgroundColor', '#FF5733');
formData.append('font', 2);

const response = await fetch('http://localhost:3000/api/upload-status', {
  method: 'POST',
  body: formData
});

const result = await response.json();
console.log(result);
```

**Response:**
```json
{
  "success": true,
  "message": "Video berhasil diupload dan akan dikirim ke status",
  "url": "http://localhost:3000/uploads/video-1234567890.mp4",
  "filename": "video-1234567890.mp4"
}
```

---

### 2. List Uploaded Videos
**GET** `/api/uploads`

Dapatkan daftar semua video yang sudah diupload.

**Request:**
```bash
curl http://localhost:3000/api/uploads
```

**Response:**
```json
{
  "files": [
    {
      "filename": "video-1234567890.mp4",
      "url": "http://localhost:3000/uploads/video-1234567890.mp4",
      "uploaded": "2025-11-28T12:00:00.000Z"
    }
  ]
}
```

---

### 3. Delete Video
**DELETE** `/api/uploads/:filename`

Hapus video yang sudah diupload.

**Request:**
```bash
curl -X DELETE http://localhost:3000/api/uploads/video-1234567890.mp4
```

**Response:**
```json
{
  "success": true,
  "message": "File berhasil dihapus"
}
```

---

### 4. Cleanup File (After Sending)
**POST** `/api/cleanup/:filename`

Hapus file temporary setelah status terkirim.

**Request:**
```bash
curl -X POST http://localhost:3000/api/cleanup/video-1234567890.mp4
```

**Response:**
```json
{
  "success": true,
  "message": "File temporary berhasil dihapus"
}
```

---

## WhatsApp Bot Commands

### Upload Status via WhatsApp
Send video to admin with command:
```
.upsw [caption] [backgroundColor] [font]
```

**Parameters:**
- `caption`: Text yang ditampilkan di status (opsional)
- `backgroundColor`: Warna background dalam format hex (default: #000000)
- `font`: Style font 0-5 (default: 0)

**Example:**
1. Send video file
2. Add caption: `.upsw "Check this out!" "#FF5733" 2`

**Response:**
```
✅ Video berhasil diupload!

📤 URL: http://localhost:3000/uploads/video-xxx.mp4
📝 Caption: Check this out!
🎨 Background: #FF5733
🔤 Font: 2

Video akan dikirim ke semua user dalam status broadcast.
```

---

## Supported Video Formats
- video/mp4
- video/quicktime (.mov)
- video/x-msvideo (.avi)
- video/x-matroska (.mkv)

**Max File Size:** 100MB

---

## Server Info
- **URL:** http://localhost:3000
- **Upload Directory:** `/public/uploads`
- **File Auto-cleanup:** Enabled (5 seconds after sending to status)

---

## Error Handling

### 400 - Bad Request
```json
{
  "error": "Tidak ada file yang diupload"
}
```

### 413 - Payload Too Large
```json
{
  "error": "File size exceeds 100MB limit"
}
```

### 415 - Unsupported Media Type
```json
{
  "error": "Hanya file video yang diperbolehkan"
}
```

### 500 - Server Error
```json
{
  "error": "Error message here"
}
```

---

## Usage Examples

### 1. Using Python requests
```python
import requests

files = {
    'video': open('video.mp4', 'rb'),
    'caption': (None, 'Hello World'),
    'backgroundColor': (None, '#FF5733'),
    'font': (None, '2')
}

response = requests.post('http://localhost:3000/api/upload-status', files=files)
print(response.json())
```

### 2. Using Node.js/axios
```javascript
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

const form = new FormData();
form.append('video', fs.createReadStream('video.mp4'));
form.append('caption', 'Hello World');
form.append('backgroundColor', '#FF5733');
form.append('font', 2);

axios.post('http://localhost:3000/api/upload-status', form, {
  headers: form.getHeaders()
}).then(res => console.log(res.data));
```

---

## Flow Diagram

```
User (WhatsApp)
    ↓
.upsw command + video
    ↓
Bot receives message
    ↓
Bot downloads video
    ↓
Bot sends to Express API
    ↓
Express uploads to /public/uploads
    ↓
Express emits 'video-uploaded' event
    ↓
Bot listens to event
    ↓
Bot sends to status@broadcast (all users)
    ↓
✅ Status sent!
    ↓
Auto cleanup file after 5s
```
