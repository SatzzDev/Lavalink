#!/usr/bin/env node

/**
 * Upload Video Status via HTTP API
 * Script ini untuk upload video ke status melalui HTTP API
 * 
 * Usage:
 * node upload-client.js <video_file> [caption] [bgColor] [font]
 * 
 * Example:
 * node upload-client.js video.mp4 "Hello World" "#FF5733" 2
 */

const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const axios = require('axios');

const args = process.argv.slice(2);

if (args.length === 0) {
    console.log(`
╭─❑ VIDEO STATUS UPLOAD CLIENT ❑─
│
│ Usage: node upload-client.js <video_file> [caption] [bgColor] [font]
│
│ Parameters:
│ • video_file: Path ke file video (required)
│ • caption: Caption di status (optional, default: "Status dari Bot")
│ • bgColor: Warna background hex (optional, default: "#000000")
│ • font: Font style 0-5 (optional, default: "0")
│
│ Examples:
│ • node upload-client.js video.mp4
│ • node upload-client.js video.mp4 "Hello World"
│ • node upload-client.js video.mp4 "Hello World" "#FF5733" 2
│
╰────────────────
    `);
    process.exit(0);
}

const videoFile = args[0];
const caption = args[1] || 'Status dari Bot';
const bgColor = args[2] || '#000000';
const font = args[3] || '0';

// Validasi file exists
if (!fs.existsSync(videoFile)) {
    console.error(`❌ File tidak ditemukan: ${videoFile}`);
    process.exit(1);
}

// Validasi file size
const stats = fs.statSync(videoFile);
const fileSizeInMB = stats.size / (1024 * 1024);

if (fileSizeInMB > 100) {
    console.error(`❌ File terlalu besar: ${fileSizeInMB.toFixed(2)}MB (max: 100MB)`);
    process.exit(1);
}

console.log(`
╭─❑ UPLOADING... ❑─
│
│ 📁 File: ${videoFile}
│ 💾 Size: ${fileSizeInMB.toFixed(2)}MB
│ 📝 Caption: ${caption}
│ 🎨 BG Color: ${bgColor}
│ 🔤 Font: ${font}
│
╰────────────────
`);

// Create FormData
const form = new FormData();
form.append('video', fs.createReadStream(videoFile));
form.append('caption', caption);
form.append('backgroundColor', bgColor);
form.append('font', font);

// Upload
axios.post('http://localhost:3000/api/upload-status', form, {
    headers: form.getHeaders(),
    maxContentLength: Infinity,
    maxBodyLength: Infinity
})
    .then(response => {
        const { success, message, url, filename } = response.data;
        
        if (success) {
            console.log(`
✅ UPLOAD BERHASIL!

│ 📤 URL: ${url}
│ 📦 Filename: ${filename}
│ 📝 Caption: ${caption}
│ 🎨 Background: ${bgColor}
│ 🔤 Font: ${font}
│
│ ℹ️ Video akan dikirim ke semua user
│    dalam status broadcast.
│
`);
        } else {
            console.error(`❌ Upload Failed: ${message}`);
        }
    })
    .catch(error => {
        if (error.response) {
            console.error(`❌ Server Error: ${error.response.status}`);
            console.error(`   Message: ${error.response.data.error}`);
        } else if (error.request) {
            console.error(`❌ No Response from Server`);
            console.error(`   Make sure Express server is running on http://localhost:3000`);
        } else {
            console.error(`❌ Error: ${error.message}`);
        }
        process.exit(1);
    });
