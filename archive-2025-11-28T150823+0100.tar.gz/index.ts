import { Boom } from '@hapi/boom'
import * as fs from 'fs'
import makeWASocket, {
DisconnectReason,
fetchLatestBaileysVersion,
useMultiFileAuthState,
delay,
downloadContentFromMessage,
AnyMessageContent,
proto
} from 'baileys'
import P from 'pino'
import FileType from 'file-type'
import { startServer, uploadEvents } from './server'
import axios from 'axios'
import FormData from 'form-data'

type ExtendedWASocket = ReturnType<typeof makeWASocket> & {
  sendButton: (jid: string, text: string, buttonText: string, buttonId: string, quoted?: any) => Promise<any>
  downloadAndSaveMediaMessage: (message: any, filename: string, attachExtension?: boolean) => Promise<string>
}
// ============ DATABASE ============
const loadDB = () => {
try {
return JSON.parse(fs.readFileSync('./db.json', 'utf8'));
} catch {
return { users: {} };
}
};

const saveDB = (data: any) => {
fs.writeFileSync('./db.json', JSON.stringify(data, null, 2));
};

let db = loadDB();
setInterval(() => saveDB(db), 30000);

// ============ CONFIG ============
const ADMIN = '6282170988479@s.whatsapp.net';

// ============ LOGGER ============
const logger = P({ level: 'silent' });

// ============ MAIN BOT ============
const startBot = async () => {
const { state, saveCreds } = await useMultiFileAuthState('session');
const { version } = await fetchLatestBaileysVersion();

const sock: ExtendedWASocket = makeWASocket({
version,
logger,
auth: state,
printQRInTerminal: true
}) as ExtendedWASocket;

// Helper: Send with typing
const reply = async (jid: string, text: string, quoted?: any) => {
await sock.presenceSubscribe(jid);
await sock.sendPresenceUpdate('composing', jid);
await delay(1500);
await sock.sendPresenceUpdate('paused', jid);
await sock.sendMessage(jid, { text }, { quoted });
};

// Helper: Create button
sock.sendButton = async (jid: string, text: string, buttonText: string, buttonId: string, quoted?: any) => {
return sock.sendMessage(jid, {
text,
footer: '© SatzzDev',
interactiveButtons: [{
name: 'quick_reply',
buttonParamsJson: JSON.stringify({
display_text: buttonText,
id: buttonId
})
}]
}, { quoted });
};
sock.downloadAndSaveMediaMessage = async (message: any, filename: string, attachExtension = true) => {
let mediaMessage = message.message?.imageMessage || message.message?.videoMessage || message.message?.documentMessage || message.message?.audioMessage || message.message?.stickerMessage;
if (!mediaMessage) throw new Error('No media found in message');

let mime = mediaMessage.mimetype || '';
let messageType = mediaMessage.mimetype ? mediaMessage.mimetype.split('/')[0] : 'unknown';

const stream = await downloadContentFromMessage(mediaMessage, messageType);
let buffer = Buffer.from([]);
for await (const chunk of stream) {
buffer = Buffer.concat([buffer, chunk]);
}

let type = await FileType.fromBuffer(buffer);
let trueFileName = attachExtension && type ? (filename + '.' + type.ext) : filename;
await fs.writeFileSync(trueFileName, buffer);
return trueFileName;
}

// ============ LISTEN TO UPLOAD EVENTS ============
uploadEvents.on('video-uploaded', async (data: any) => {
try {
const { videoUrl, caption, backgroundColor, font } = data;

// Get all user JIDs from database
const userJids = Object.keys(db.users);

console.log(`📤 Mengirim video status ke ${userJids.length} user...`);

// Send to status broadcast
await sock.sendMessage('status@broadcast', {
video: {
url: videoUrl
},
caption: caption
} as any, {
backgroundColor,
font,
statusJidList: userJids,
broadcast: true
} as any);

console.log('✅ Video status berhasil dikirim!');

// Cleanup file after sending (optional - hapus setelah dikirim)
setTimeout(() => {
const filePath = data.filePath;
if (fs.existsSync(filePath)) {
fs.unlinkSync(filePath);
console.log(`🗑️ File temporary dihapus: ${data.filename}`);
}
}, 5000);

// Notify admin
await reply(ADMIN, `✅ Video status berhasil dikirim ke ${userJids.length} user dengan caption: "${caption}"`, undefined);
} catch (error: any) {
console.error('❌ Error mengirim status:', error);
await reply(ADMIN, `❌ Error mengirim status: ${error.message}`, undefined);
}
});

// ============ EVENT HANDLER ============
sock.ev.on('connection.update', (update) => {
const { connection, lastDisconnect } = update;
if (connection === 'close') {
const shouldReconnect = (lastDisconnect?.error as Boom)?.output?.statusCode !== DisconnectReason.loggedOut;
if (shouldReconnect) startBot();
}
});

sock.ev.on('creds.update', saveCreds);

sock.ev.on('messages.upsert', async ({ messages }) => {
const msg = messages[0];
if (!msg.message) return;
if (msg.key.remoteJid.endsWith('@g.us')) return
const from = msg.key.remoteJid!;

// Get text from various message types
let text = '';
try {
text = msg.message?.conversation ||
msg.message?.extendedTextMessage?.text ||
msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId ||
msg.message?.buttonsResponseMessage?.selectedButtonId ||
msg.message?.templateButtonReplyMessage?.selectedId ||
(msg.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson
? JSON.parse(msg.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id
: '') ||
'';
} catch (e) {
text = '';
}

if (!text || !text.startsWith('.')) return;

const [cmd, ...args] = text.slice(1).trim().split(/\s+/);

// Init user
if (!db.users[from]) {
db.users[from] = { username: null, password: null, createdAt: new Date().toISOString() };
}

// ============ COMMANDS ============
switch (cmd.toLowerCase()) {

// 1. ADDUSER - Tambah user baru
case 'adduser':
if (from !== ADMIN) {
await reply(from, '❌ Khusus admin!', msg);
break;
}

const [newJid, newUsername, newPassword] = args;
if (!newJid || !newUsername || !newPassword) {
await reply(from, '❌ Format: .adduser <JID> <username> <password>\n\nContoh: .adduser 6282170988479@s.whatsapp.net john_doe password123', msg);
break;
}

const fullJid = newJid.includes('@') ? newJid : newJid + '@s.whatsapp.net';

if (db.users[fullJid]) {
await reply(from, '❌ User sudah terdaftar!', msg);
break;
}

db.users[fullJid] = { 
username: newUsername, 
password: newPassword, 
createdAt: new Date().toISOString() 
};

await reply(from, `✅ User berhasil ditambahkan!\n\n👤 JID: ${fullJid}\n📝 Username: ${newUsername}\n🔑 Password: ${newPassword}`, msg);
break;

// 2. LISTUSER - Tampilkan daftar user
case 'listuser':
if (from !== ADMIN) {
await reply(from, '❌ Khusus admin!', msg);
break;
}

const users = Object.entries(db.users);
if (users.length === 0) {
await reply(from, '❌ Belum ada user terdaftar.', msg);
break;
}

let listMsg = `╭─❑ *DAFTAR USER* ❑─\n│\n`;
users.forEach(([jid, user]: [string, any], idx: number) => {
listMsg += `│ ${idx + 1}. ${user.username || '(no username)'}\n`;
listMsg += `│    JID: ${jid}\n`;
listMsg += `│    Pass: ${user.password || '(no password)'}\n`;
listMsg += `│    Created: ${new Date(user.createdAt).toLocaleString('id-ID')}\n│\n`;
});
listMsg += `╰────────────────\n\nTotal: ${users.length} user`;

await reply(from, listMsg, msg);
break;

// 3. DELUSER - Hapus user
case 'deluser':
if (from !== ADMIN) {
await reply(from, '❌ Khusus admin!', msg);
break;
}

const delJid = args[0];
if (!delJid) {
await reply(from, '❌ Format: .deluser <JID>\n\nContoh: .deluser 6282170988479@s.whatsapp.net', msg);
break;
}

const delFullJid = delJid.includes('@') ? delJid : delJid + '@s.whatsapp.net';

if (!db.users[delFullJid]) {
await reply(from, '❌ User tidak ditemukan!', msg);
break;
}

const delUsername = db.users[delFullJid].username;
delete db.users[delFullJid];

await reply(from, `✅ User ${delUsername} (${delFullJid}) berhasil dihapus!`, msg);
break;

// 4. UPSW - Upload Video ke Status
case 'upsw':
if (from !== ADMIN) {
await reply(from, '❌ Khusus admin!', msg);
break;
}

// Check if message has video
if (!msg.message?.videoMessage) {
const helpUpsw = `📤 *UPLOAD VIDEO KE STATUS*\n\n` +
`Format: Reply video dengan .upsw [caption] [bgColor] [font]\n\n` +
`📝 Caption: Teks yang ditampilkan (opsional)\n` +
`🎨 Background Color: Hex color code (default: #000000)\n` +
`🔤 Font: 0-5 (default: 0)\n\n` +
`Contoh: .upsw "Halo semua!" "#FF5733" 2\n\n` +
`📌 Langkah:\n` +
`1️⃣ Kirim video file\n` +
`2️⃣ Reply video dengan .upsw [parameters]`;

await reply(from, helpUpsw, msg);
break;
}

try {
const [caption = '', bgColor = '#000000', fontNum = '0'] = args;

// Download video dari pesan
const videoPath = await sock.downloadAndSaveMediaMessage(msg, `./temp_video_${Date.now()}`);

// Create form data
const form = new FormData();
form.append('video', fs.createReadStream(videoPath));
form.append('caption', caption || 'Status dari Bot');
form.append('backgroundColor', bgColor);
form.append('font', fontNum);

// Upload ke server Express
const response = await axios.post(`http://de-05.orihost.com:${process.env.SERVER_PORT}/api/upload-status`, form, {
headers: form.getHeaders()
});

if (response.data.success) {
await reply(from, 
`✅ Video berhasil diupload!\n\n` +
`📤 URL: ${response.data.url}\n` +
`📝 Caption: ${caption || 'Status dari Bot'}\n` +
`🎨 Background: ${bgColor}\n` +
`🔤 Font: ${fontNum}\n\n` +
`⏳ Video akan dikirim ke semua user...`, msg);
} else {
await reply(from, `❌ Error: ${response.data.error}`, msg);
}

// Cleanup local temp file
setTimeout(() => {
if (fs.existsSync(videoPath)) {
fs.unlinkSync(videoPath);
}
}, 2000);

} catch (error: any) {
await reply(from, `❌ Error: ${error.message}`, msg);
}
break;

// 5. HELP
case 'help':
case 'menu':
const helpMsg = 
`╭─❑ *MENU BOT* ❑─\n` +
`│\n` +
`│ 👥 *User Management*\n` +
`│ • .adduser <JID> <username> <password>\n` +
`│ • .listuser - Lihat semua user\n` +
`│ • .deluser <JID> - Hapus user\n` +
`│\n` +
`│ 📤 *Status Upload*\n` +
`│ • .upsw [caption] [bgColor] [font]\n` +
`│   (kirim video dengan caption ini)\n` +
`│\n` +
`╰────────────────`;

await reply(from, helpMsg, msg);
break;
}
});

return sock;
};

// Start Express server
startServer();

// Start Bot
startBot();
